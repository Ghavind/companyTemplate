
# Company Profile Website

This website is published at https://vetjurv4.github.io/company-profile-template/



## Mission

This website is designed through a combination of multiple section components from free templates that were found online. This was one
of the templates I designed for some finance company but a better design was chosen, so feel free to contribute or use it.

![screenshot-1](https://user-images.githubusercontent.com/30547148/173818485-1ea7864b-5dfd-4a7f-a005-c427b53cfdb9.png)
![screenshot-2](https://user-images.githubusercontent.com/30547148/173818501-4b33275b-35ea-4266-bb35-dbc1e068e7fb.png)
![screenshot-3](https://user-images.githubusercontent.com/30547148/173818534-c6c289ff-c283-46be-916d-8c5d584deb1b.png)
